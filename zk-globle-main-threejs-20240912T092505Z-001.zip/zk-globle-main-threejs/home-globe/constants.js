export const GLOBE_RADIUS = 100;
